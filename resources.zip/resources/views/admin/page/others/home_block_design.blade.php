@extends('admin/include/masterlayout')
@section('title')
Manage Site
@endsection
@section('content')
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1>Home page Block Design</h1>
        </div>

        <div class="section-body">
            <div class="row card">
                <div class="col-12 col-md-12 col-lg-12">
                    <div class="">
                        <div class="card-header">
                            <h4>Block 1</h4>
                        </div>
                        <div class="card-body">
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
</div>
@endsection