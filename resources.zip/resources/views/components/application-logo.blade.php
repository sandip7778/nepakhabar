<div class="login-brand">
    <img src="{{ asset('assets_news/img/logo/Logo-1.png') }}" alt="logo" width="100"
        class="shadow-light rounded-circle">
</div>
